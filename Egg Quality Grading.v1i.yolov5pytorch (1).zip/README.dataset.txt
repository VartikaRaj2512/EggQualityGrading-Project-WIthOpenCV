# Egg Quality Grading > 2024-08-22 3:11pm
https://universe.roboflow.com/vartikaraj/egg-quality-grading-wlgy5

Provided by a Roboflow user
License: CC BY 4.0

The Egg Quality Grading System is an OpenCV-based machine learning project designed to assist poultry farms in classifying various types of eggs, including white, brown, blood-stained, dirt-stained, and calcium-deposited eggs. By leveraging CCTV cameras for surveillance, the system automates the detection and classification process, enabling efficient and simultaneous segregation of different egg types. This automation reduces the reliance on manual labor, leading to significant cost savings.